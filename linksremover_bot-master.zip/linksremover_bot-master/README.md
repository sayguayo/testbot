## LinksRemover Bot Help

This bot implements simple anti-spam technique - it deletes all posts which contains link or mentions @username or been forwarded from somewhere.

This bot does not ban anybody, it only deletes messages by the rules listed above. The idea is that in these 24 hours the spamer would be banned anyway for posting spam to other groups that are not protected by this bot.


## Usage

1. Add [@linksremover_bot](https://t.me/linksremover_bot) to your group.
2. Go to group settings / users list / promote user to admin
3. Enable only one item: Delete messages
4. Click SAVE button
5. Enjoy!

To get more help submit `/help` command to the bot.


## Fork
Master repository is [github.com/lorien/daysandbox_bot](https://github.com/lorien/daysandbox_bot).
Fork is initiated to make the bot remove any links and not only from users that joined the group less than 24 hours ago.
